# Firmware 1.1 BETA 1 ROMs for rosco_m68k

## To burn to ROM

```
# ROMDEVICE=AT28C64B ./burn.sh
```

If you are using different ROMs, change the AT28C64B in the command
above to reflect your ROM device.

## To use with MAME

The `mame/rosco.zip` file can be dropped into your mame's
`roms` directory, replacing the existing rosco.zip.

## Included Binaries

For convenience, a few program binaries are included in this
zip. These have been compiled against the new standard libs
for FW 1.1.

## Building from source

To build from source, pull the latest develop from https://github.com/rosco-m68k/rosco_m68k
and build as normal in the `code/firmware/rosco_m68k_v1.1` directory.

There are also new standard libraries that you will need to build,
do `make clean install` in `code/software/libs`. 

You should then be able to build the program binaries as normal.

